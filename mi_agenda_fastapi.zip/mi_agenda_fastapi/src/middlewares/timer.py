# src/middlewares/timer.py
import time
from fastapi import Request


async def response_time_middleware(request: Request, call_next):
    # mide cuanto tarda cada peticion y lo manda en un header
    inicio = time.time()
    response = await call_next(request)
    response.headers["X-Process-Time"] = f"{time.time() - inicio:.4f} s"
    return response
