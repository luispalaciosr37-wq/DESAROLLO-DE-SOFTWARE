# src/routers/views.py
from fastapi import APIRouter, Request, Depends, Form
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates
from pydantic import ValidationError
from sqlmodel import Session, select
from src.database import get_session
from src.models.agenda import Contacto, ContactoCreate

templates = Jinja2Templates(directory="src/templates")
router = APIRouter(prefix="/views", tags=["Vistas Web (Jinja2)"])


def mostrar_agenda(request: Request, session: Session, error: str = None):
    contactos = session.exec(select(Contacto)).all()
    return templates.TemplateResponse(request, "agenda.html", {"contactos": contactos, "error": error})


@router.get("/agenda")
def ver_agenda(request: Request, session: Session = Depends(get_session)):
    return mostrar_agenda(request, session)


# RETO 3: recibe el formulario HTML
@router.post("/agenda")
def agregar_contacto(request: Request, nombre: str = Form(...), telefono: str = Form(...),
                     mail: str = Form(...), session: Session = Depends(get_session)):
    try:
        # reutilizo la validacion de ContactoCreate
        datos = ContactoCreate(nombre=nombre, telefono=telefono, mail=mail)
    except ValidationError:
        return mostrar_agenda(request, session, "Datos inválidos: revisa nombre, teléfono (7 a 15 dígitos) y correo")

    session.add(Contacto.model_validate(datos))
    session.commit()
    # redirige para que al recargar no se reenvíe el formulario
    return RedirectResponse("/views/agenda", status_code=303)
