# src/routers/agenda.py
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import Session, select
from src.database import get_session
from src.models.agenda import Contacto, ContactoCreate, ContactoUpdate
from src.models.user import Usuario
from src.auth.dependencies import get_current_user

router = APIRouter(prefix="/agenda", tags=["Agenda CRUD"])


def buscar_contacto(id: int, session: Session, user: Usuario) -> Contacto:
    # busca el contacto y revisa que sea del usuario (RETO 2)
    contacto = session.get(Contacto, id)
    if not contacto or contacto.user_id != user.id:
        raise HTTPException(status_code=404, detail="Contacto no encontrado")
    return contacto


@router.get("", response_model=List[Contacto])
def get_contactos(session: Session = Depends(get_session), user: Usuario = Depends(get_current_user)):
    # solo regresa los contactos del usuario logueado
    return session.exec(select(Contacto).where(Contacto.user_id == user.id)).all()


@router.get("/{id}", response_model=Contacto)
def get_contacto(id: int, session: Session = Depends(get_session), user: Usuario = Depends(get_current_user)):
    return buscar_contacto(id, session, user)


@router.post("", response_model=Contacto, status_code=status.HTTP_201_CREATED)
def crear_contacto(contacto_in: ContactoCreate, session: Session = Depends(get_session),
                   user: Usuario = Depends(get_current_user)):
    nuevo = Contacto.model_validate(contacto_in)
    nuevo.user_id = user.id  # el contacto queda ligado al usuario
    session.add(nuevo)
    session.commit()
    session.refresh(nuevo)
    return nuevo


@router.put("/{id}", response_model=Contacto)
def actualizar_contacto(id: int, contacto_in: ContactoUpdate, session: Session = Depends(get_session),
                        user: Usuario = Depends(get_current_user)):
    contacto = buscar_contacto(id, session, user)
    # solo cambia los campos que mandó el cliente
    datos = contacto_in.model_dump(exclude_unset=True)
    for campo, valor in datos.items():
        setattr(contacto, campo, valor)
    session.add(contacto)
    session.commit()
    session.refresh(contacto)
    return contacto


@router.delete("/{id}")
def eliminar_contacto(id: int, session: Session = Depends(get_session), user: Usuario = Depends(get_current_user)):
    contacto = buscar_contacto(id, session, user)
    session.delete(contacto)
    session.commit()
    return {"mensaje": f"Contacto {id} eliminado por @{user.username}"}
