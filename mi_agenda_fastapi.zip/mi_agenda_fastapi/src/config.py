# src/config.py
# Aqui guardo las variables que se usan en varios archivos

DATABASE_URL = "sqlite:///./agenda.db"

SECRET_KEY = "cambiar_esta_llave_en_produccion"  # en un proyecto real va en una variable de entorno
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60
