# src/database.py
from sqlmodel import SQLModel, create_engine, Session
from src.config import DATABASE_URL

# check_same_thread=False solo se necesita con SQLite
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})


def create_db_and_tables():
    # crea las tablas si todavia no existen
    SQLModel.metadata.create_all(engine)


def get_session():
    # abre una sesion por peticion y la cierra al terminar
    with Session(engine) as session:
        yield session
