# src/models/agenda.py
from typing import Optional
from sqlmodel import SQLModel, Field
from pydantic import EmailStr, constr


class ContactoBase(SQLModel):
    nombre: str = Field(min_length=2, max_length=50)
    telefono: str
    mail: str


class Contacto(ContactoBase, table=True):
    # tabla de contactos
    id: Optional[int] = Field(default=None, primary_key=True)
    # RETO 2: llave foranea para saber de que usuario es cada contacto
    user_id: Optional[int] = Field(default=None, foreign_key="usuario.id")


class ContactoCreate(ContactoBase):
    # aqui se validan el telefono (7 a 15 digitos) y el correo
    telefono: constr(pattern=r"^\d{7,15}$")
    mail: EmailStr


class ContactoUpdate(SQLModel):
    # todo opcional para poder actualizar solo un campo
    nombre: Optional[str] = None
    telefono: Optional[str] = None
    mail: Optional[EmailStr] = None
