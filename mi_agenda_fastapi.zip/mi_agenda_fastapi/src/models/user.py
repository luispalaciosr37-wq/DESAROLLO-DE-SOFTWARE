# src/models/user.py
from typing import Optional
from sqlmodel import SQLModel, Field
from pydantic import EmailStr


class Usuario(SQLModel, table=True):
    # tabla de usuarios
    id: Optional[int] = Field(default=None, primary_key=True)
    username: str = Field(index=True, unique=True, min_length=3)
    email: str
    hashed_password: str  # nunca se guarda la contraseña en texto plano


class UsuarioCreate(SQLModel):
    # datos que se piden al registrarse
    username: str
    email: EmailStr
    password: str


class UsuarioRead(SQLModel):
    # lo que se regresa al cliente (sin la contraseña)
    id: int
    username: str
    email: str


class Token(SQLModel):
    access_token: str
    token_type: str
