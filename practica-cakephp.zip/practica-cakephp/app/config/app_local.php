<?php

use function Cake\Core\env;

return [
    'debug' => filter_var(env('DEBUG', true), FILTER_VALIDATE_BOOLEAN),

    'Security' => [
        'salt' => env('SECURITY_SALT', '9afaae5d42b88eda22e0c0506264017ac30ecebbdaddc2b0cc880e5623a49b7b'),
    ],

    'Datasources' => [
        'default' => [
            'host' => 'db',
            'username' => 'cake_user',
            'password' => 'cake_password',
            'database' => 'cake_db',
            'url' => env('DATABASE_URL', null),
        ],

        'test' => [
            'host' => 'db',
            'username' => 'cake_user',
            'password' => 'cake_password',
            'database' => 'test_cake_db',
            'url' => env('DATABASE_TEST_URL', null),
        ],
    ],

    'EmailTransport' => [
        'default' => [
            'host' => 'localhost',
            'port' => 25,
            'username' => null,
            'password' => null,
            'client' => null,
            'url' => env('EMAIL_TRANSPORT_DEFAULT_URL', null),
        ],
    ],
];
